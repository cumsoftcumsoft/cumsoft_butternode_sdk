*Cumsoft_Butternode_V3_<3*


<br> 📁 Cumsoft_Butternode_SDK_v3
<br>│├─ 📁 Cumsoft_Butternode_SDK_v3
<br>│ | ├─ 📁 Cumsoft_Butternode_SDK_v3
<br>
<br>
<br>
<br>├─ 📁 Java
<br>│├─ 📁 Genenv
<br>│├─ 📁 Main_App
<br>│ | ├─ 📁 Resources
<br>|
<br>├─ 📁 Linux
<br>│├─ Firstbootinstaller.sh
<br>│├─ 📁 Genenv
<br>│├─ 📁 Main_App
<br>│ | ├─ app_404.html
<br>│ | ├─ app_invokephp.html
<br>│ | ├─ app_invokepy.html
<br>│ | ├─ Linux_app.html
<br>│ | ├─ 📁 Resources
<br>│ | |  ├─ app_404.html
<br>│ | |  ├─ robots.txt
<br>|
<br>├─ REadMe.md
<br>|
<br>├─ 📁 Windows
<br>│ | ├─ adminbypass.bat
<br>│ | ├─ firstbootinstaller.ps1
<br>│├─ 📁 Genenv
<br>│ | ├─ logger.txt.txt
<br>│├─ 📁 Main_App
<br>│ | ├─ app_404.html
<br>│ | ├─ app_invokecsharp.html
<br>│ | ├─ app_invokevbs.html
<br>│ | ├─ 📁 Resources
<br>│ | |  ├─ getoperatingsysteminfo.hta
<br>│ | |  ├─ getproductkey.vbs
<br>│ | |  ├─ htmlcreatehtml.html
<br>│ | |  ├─ Launchsyntax.hta
<br>│ | |  ├─ Launchsyntaxother.hta
<br>│ | |  ├─ Powershellsecrets.ps1
<br>│ | |  ├─ Winregistrybypass.reg.txt
<br>│ | |  ├─ wooper.hta
<br>│ | ├─ robots.txt
<br>│ | ├─ Windows_app.html
<br>│ | ├─ 📁 Network
<br>│ | ├─ notes.ps1
<br>|
<br>|
<br>|
<br>├─ */Github Standard Packages/*
<br>├─ .gitignore
<br>├─ package.json
<br>├─ node_modules/

