#!/bin/bash
SCRIPT_PATH="/Users/cumsoft_clone_69/Desktop/oneglove.sh"

sleep 2
echo "   ******                                         ****   **"                   
echo "  **////**                                       /**/   /**"                     
echo " **    //  **   ** **********   ******  ******  ****** ******"                   
echo "/**       /**  /**//**//**//** **////  **////**///**/ ///**/"                    
echo "/**       /**  /** /** /** /**//***** /**   /**  /**    /**"                     
echo "//**    **/**  /** /** /** /** /////**/**   /**  /**    /**"                     
echo " //****** //****** *** /** /** ****** //******   /**    //**"                    
echo "  //////   ////// ///  //  // //////   //////    //      //"                     
echo " ******             **     **                                         **"        
echo "/*////**           /**    /**                                        /**"        
echo "/*   /**  **   ** ****** ******  *****  ****** *******   ******      /**  *****" 
echo "/******  /**  /**///**/ ///**/  **///**//**//*//**///** **////**  ****** **///**"
echo "/*//// **/**  /**  /**    /**  /******* /** /  /**  /**/**   /** **///**/*******"
echo "/*    /**/**  /**  /**    /**  /**////  /**    /**  /**/**   /**/**  /**/**////" 
echo "/******* //******  //**   //** //******/***    ***  /**//****** //******//******"
echo "///////   //////    //     //   ////// ///    ///   //  //////   //////  //////" 
echo "  ******** *******   **   ** **      **  ****"                                   
echo " **////// /**////** /**  ** /**     /** */// *"                                  
echo "/**       /**    /**/** **  /**     /**/    /*"                                  
echo "/*********/**    /**/****   //**    **    ***"                                   
echo "////////**/**    /**/**/**   //**  **    /// *"                                  
echo "       /**/**    ** /**//**   //****    *   /*"                                  
echo " ******** /*******  /** //**   //**    / ****"                                   
echo "////////  ///////   //   //     //      ////"   
sleep 1
echo "Please make a selection from the List.."
echo "[1]operation1 | [7]operation7 | [13]operation13 | [19]operation19"
echo "[2]operation2 | [8]operation8 | [14]operation14 | [20]operation20"
echo "[3]operation3 | [9]operation9 | [15]operation15 | [21]operation21"
echo "[4]operation4 | [10]operation10 | [16]operation16 | [22]operation22"
echo "[5]operation5 | [11]operation11 | [17]operation17 | [23]operation23"
echo "[6]operation6 | [12]operation12 | [18]operation18 | [24]operation24"


read n
case $n in
  1) echo "You chose Option 2";;
  2) echo "You chose Option 2";;
  3) echo "You chose Option 3";;
  4) echo "You chose Option 4";;
  5) echo "You chose Option 5";;
  6) echo "You chose Option 6";;
  7) echo "You chose Option 7";;
  8) echo "You chose Option 8";;
  9) echo "You chose Option 9";;
  10) echo "You chose Option 10";;
  11) echo "You chose Option 11";;
  12) echo "You chose Option 12";;
  13) echo "You chose Option 13";;
  14) echo "You chose Option 14";;
  15) echo "You chose Option 15";;
  16) echo "You chose Option 16";;
  17) echo "You chose Option 17";;
  18) echo "You chose Option 18";;
  19) echo "You chose Option 19";;
  20) echo "You chose Option 20";;
  "111" | "222") python3 /Users/cumsoft_clone_69/Desktop/butternode_sdk_v3/Linux/Scripts/cumsoftbutternodesdkmenu.py;;
  21) echo "You chose Option 21";;
  22) echo "You chose Option 22";;
  23) echo "You chose Option 23";;
  24) echo "You chose Option 24";;
  *) echo "invalid option";;
esac


  ## // find-ping-time.sh //
  ##
  ## $ips="$(host -t a www.google.com | awk '{ print $4}')"
  ## for i in $ips; do ping -q -c 4 "$i"; done;;
  