



:: Shutdown ALL LOcal IPs

:: Find all Local IPs
$arp -a
:: Shutdown all computers via local address
$shutdown -i





:: Restart into Bios
$shutdown /r /fw /f /t 0

:: Ping Recursively Example: google.com
$ping -t google.com

:: Trace Route
$tracert google.com

:: Network Stats
$netstat
:: Network OpenPorts
$netstat -af
:: Network Connections PID
$netstat -o
:: Network Packet Stats
$netstat -e -t 5

:: Route Table
$route print
:: Route add route
$route add
:: Route delete route
$route delete

:: clearscreen
$cls

:: Search all tasks Example: script
$tasklist | findstr script
:: Killing Task via PID Example: 2018
$taskkill /f /pid 2018

::Shutoff Firewall
$netsh advfirewall set allprofiles state off
::Turnon Firewall
$netsh advfirewall set allprofiles state on

:: IPCONFIG "all" with find string
$ipconfig /all | findstr
:: Releases Current IP
$ipconfig /release
:: renew Current IP
$ipconfig /renew

:: Shows all saved DNS
$ipconfig /displaydns 
:: Shows all saved DNS and saved to clipboard
$ipconfig /displaydns | clip
:: Remove DNS Cache
$ipconfig /flushdns

:: lookup url IP example:google.com
$nslookup google.com


:: SYSTEM WIDE TROUBLESHOOTING

:: Checkdisk for errors
$chkdsk /f
$chkdsk /r
:: System File Checker
$sfc /scannow
:: Deployment Image Service & Management
$DISM /Online /Cleanup /CheckHealth
$DISM /Online /Cleanup /ScanHealth
$DISM /Online /Cleanup /RestoreHealth




:: The following example runs the native command sort.exe with redirected input and output streams.
 
$processOptions = @{
    FilePath = "sort.exe"
    RedirectStandardInput = "TestSort.txt"
    RedirectStandardOutput = "Sorted.txt"
    RedirectStandardError = "SortError.txt"
    UseNewEnvironment = $true
}
Start-Process @processOptions