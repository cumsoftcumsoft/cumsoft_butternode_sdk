import tkinter
import subprocess

my_w=tkinter.Tk() # Parent window  "my_w"
my_w.title("CUMSOFTBUTTERNODESDK")
my_w.geometry("270x240")
my_w.configure(background='#fff2a6')


#Define Row 1

def button1_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["/usr/bin/python3", "/Users/cumsoft_clone_69/Desktop/butternode_sdk_v5/Linux/Scripts/poop.py"])


button1=tkinter.Button(my_w, 
                       text="button1", 
                       activeforeground="red",
                       command=button1_callback,
                       fg="black",
                       state="active"
                       )
button1.grid(row=1,column=0)

def button2_callback():
    subprocess.run(["whoami"])


button2=tkinter.Button(my_w, 
                       text="button2", 
                       activeforeground="red",
                       command=button2_callback,
                       fg="black",
                       state="disabled"
                       )
button2.grid(row=2,column=0)

def button3_callback():
    subprocess.run(["whoami"])


button3=tkinter.Button(my_w, 
                       text="button3", 
                       activeforeground="red",
                       command=button3_callback,
                       fg="black",
                       state="disabled"
                       )
button3.grid(row=3,column=0)

def button4_callback():
    subprocess.run(["whoami"])


button4=tkinter.Button(my_w, 
                       text="button4", 
                       activeforeground="red",
                       command=button4_callback,
                       fg="black",
                       state="disabled"
                       )
button4.grid(row=5,column=0)

def button5_callback():
    subprocess.run(["whoami"])


button5=tkinter.Button(my_w, 
                       text="button5", 
                       activeforeground="red",
                       command=button5_callback,
                       fg="black",
                       state="disabled"
                       )
button5.grid(row=6,column=0)

def button6_callback():
    subprocess.run(["whoami"])


button6=tkinter.Button(my_w, 
                       text="button6", 
                       activeforeground="red",
                       command=button6_callback,
                       fg="black",
                       state="disabled"
                       )
button6.grid(row=7,column=0)

def button7_callback():
    subprocess.run(["whoami"])


button7=tkinter.Button(my_w, 
                       text="button7", 
                       activeforeground="red",
                       command=button7_callback,
                       fg="black",
                       state="disabled"
                       )
button7.grid(row=8,column=0)

#Define Row 2

def button8_callback():
    subprocess.run(["whoami"])


button8=tkinter.Button(my_w, 
                       text="button8", 
                       activeforeground="red",
                       command=button8_callback,
                       fg="black",
                       state="disabled"
                       )
button8.grid(row=1,column=1)

def button9_callback():
    subprocess.run(["whoami"])


button9=tkinter.Button(my_w, 
                       text="button9", 
                       activeforeground="red",
                       command=button9_callback,
                       fg="black",
                       state="disabled"
                       )
button9.grid(row=2,column=1)

def button10_callback():
    subprocess.run(["whoami"])


button10=tkinter.Button(my_w, 
                        text="button10", 
                        activeforeground="red",
                        command=button10_callback,
                        fg="black",
                        state="disabled"
                        )
button10.grid(row=3,column=1)

def button11_callback():
    subprocess.run(["whoami"])


button11=tkinter.Button(my_w, 
                        text="button11", 
                        activeforeground="red",
                        command=button11_callback,
                        fg="black",
                        state="disabled"
                        )
button11.grid(row=5,column=1)

def button12_callback():
    subprocess.run(["whoami"])


button12=tkinter.Button(my_w, 
                        text="button12",
                        activeforeground="red",
                        command=button12_callback,
                        fg="black",
                        state="disabled"
                        )
button12.grid(row=6,column=1)

def button13_callback():
    subprocess.run(["whoami"])


button13=tkinter.Button(my_w, 
                        text="button13", 
                        activeforeground="red",
                        command=button13_callback,
                        fg="black",
                        state="disabled"
                        )
button13.grid(row=7,column=1)

def button14_callback():
    subprocess.run(["whoami"])


button14=tkinter.Button(my_w, 
                        text="button14", 
                        activeforeground="red",
                        command=button14_callback,
                        fg="black",
                        state="disabled"
                        )
button14.grid(row=8,column=1)

#Define Row 3

def button15_callback():
    subprocess.run(["whoami"])


button15=tkinter.Button(my_w, 
                        text="button15", 
                        activeforeground="red",
                        command=button15_callback,
                        fg="black",
                        state="disabled"
                        )
button15.grid(row=1,column=2)

def button16_callback():
    subprocess.run(["whoami"])


button16=tkinter.Button(my_w, 
                        text="button16", 
                        activeforeground="red",
                        command=button16_callback,
                        fg="black",
                        state="disabled"
                        )
button16.grid(row=2,column=2)

def button17_callback():
    subprocess.run(["whoami"])


button17=tkinter.Button(my_w, 
                        text="button17", 
                        activeforeground="red",
                        command=button17_callback,
                        fg="black",
                        state="disabled"
                        )
button17.grid(row=3,column=2)

def button18_callback():
    subprocess.run(["whoami"])


button18=tkinter.Button(my_w, 
                        text="button18", 
                        activeforeground="red",
                        command=button18_callback,
                        fg="black",
                        state="disabled"
                        )
button18.grid(row=5,column=2)

def button19_callback():
    subprocess.run(["whoami"])


button19=tkinter.Button(my_w, 
                        text="button19", 
                        activeforeground="red",
                        command=button19_callback,
                        fg="black",
                        state="disabled"
                        )
button19.grid(row=6,column=2)

def button20_callback():
    subprocess.run(["whoami"])


button20=tkinter.Button(my_w, 
                        text="button20", 
                        activeforeground="red",
                        command=button20_callback,
                        fg="black",
                        state="disabled"
                        )
button20.grid(row=7,column=2)

def button21_callback():
    subprocess.run(["clear"])


button21=tkinter.Button(my_w, 
                        text="button21", 
                        activeforeground="red",
                        command=button21_callback,
                        fg="black",
                        state="active"
                        )
button21.grid(row=8,column=2)


button22=tkinter.Button(my_w, text="Exit", activeforeground="red", command=my_w.destroy)
button22.grid(row=9,column=1)



my_w.mainloop()

