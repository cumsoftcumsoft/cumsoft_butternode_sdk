from datetime import datetime
import socket

server_address = ('localhost', 6789)
max_size = 1000

print('Starting the server at', datetime.now())
print('waiting for client to call.')
server = socket.socket(socket.AF_INET, socket.SOCK.STREAM)
server.bind(address)
server.listen(5)

client, addr = server.accept()
data, client = server.recv(max_size)

print('At', datetime.now(), client, 'said', data)
client.sendto(b'Are you talking to me?')
client.close()
server.close()


## NEWER-BACKUP ##

#import socketserver
#
#class MyTCPHandler(socketserver.BaseRequestHandler):
#    """
#    The request handler class for our server.
#
#    It is instantiated once per connection to the server, and must
#    override the handle() method to implement communication to the
#    client.
#    """
#
#    def handle(self):
#        # self.request is the TCP socket connected to the client
#        self.data = self.request.recv(1024).strip()
#        print("{} wrote:".format(self.client_address[0]))
#        print(self.data)
#        # just send back the same data, but upper-cased
#        self.request.sendall(self.data.upper())
#
#if __name__ == "__main__":
#    HOST, PORT = "localhost", 9999
#
#    # Create the server, binding to localhost on port 9999
#    with socketserver.TCPServer((HOST, PORT), MyTCPHandler) as server:
#        # Activate the server; this will keep running until you
#        # interrupt the program with Ctrl-C
#        server.serve_forever()