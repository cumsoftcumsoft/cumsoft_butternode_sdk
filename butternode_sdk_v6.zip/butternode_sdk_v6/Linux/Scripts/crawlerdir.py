import os

def count_files(directory):
    count = 0
    for root, dirs, files in os.walk(directory):
        file_count = len(files)
        count += file_count
        print(f"Directory: {root}\t\tFiles: {file_count}")
    return count

# Specify the root directory where you want to start the file count
root_directory = "/"

total_files = count_files(root_directory)
print("\nTotal files in the system:", total_files)