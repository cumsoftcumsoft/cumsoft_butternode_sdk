import tkinter
import subprocess
import os

os.environ["TK_SILENCE_DEPRECATION"] = "1"

my_w = tkinter.Tk()
my_w.title("CUMSOFTBUTTERNODESDK")
my_w.geometry("280x230")
my_w['background']='#856ff8'

 # ____        _   _             __ 
 #|  _ \      | | | |           /_ |
 #| |_) |_   _| |_| |_ ___  _ __ | |
 #|  _ <| | | | __| __/ _ \| '_ \| |
 #| |_) | |_| | |_| || (_) | | | | |
 #|____/ \__,_|\__|\__\___/|_| |_|_|
                                   
def button1_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["/usr/bin/python3", "/CHOOSE/CORRECT/PATH/butternode_sdk_v6/Linux/Scripts/placeholder.py"])


button1=tkinter.Button(my_w, 
                       text="HelloWorld", 
                       activeforeground="red",
                       command=button1_callback,
                       fg="black",
                       state="active"
                       )
button1.grid(row=1,column=0)

#  ____        _   _              ___  
# |  _ \      | | | |            |__ \ 
# | |_) |_   _| |_| |_ ___  _ __    ) |
# |  _ <| | | | __| __/ _ \| '_ \  / / 
# | |_) | |_| | |_| || (_) | | | |/ /_ 
# |____/ \__,_|\__|\__\___/|_| |_|____|
                                                                 
def button2_callback():
    ### <!--- *** REFRESHINGLY *** --->    
    subprocess.run(["/usr/bin/python3", "/CHOOSE/CORRECT/PATH/butternode_sdk_v6/Linux/Network/TCPclient.py"])


button2=tkinter.Button(my_w, 
                       text="TCPclient", 
                       activeforeground="red",
                       command=button2_callback,
                       fg="black",
                       state="disabled"
                       )
button2.grid(row=2,column=0)

#  ____        _   _              ____  
# |  _ \      | | | |            |___ \ 
# | |_) |_   _| |_| |_ ___  _ __   __) |
# |  _ <| | | | __| __/ _ \| '_ \ |__ < 
# | |_) | |_| | |_| || (_) | | | |___) |
# |____/ \__,_|\__|\__\___/|_| |_|____/ 
                                       
def button3_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["/usr/bin/python3", "/CHOOSE/CORRECT/PATH/butternode_sdk_v6/Linux/Network/TCPserver.py"])


button3=tkinter.Button(my_w, 
                       text="TCPserver", 
                       activeforeground="red",
                       command=button3_callback,
                       fg="black",
                       state="disabled"
                       )
button3.grid(row=3,column=0)

#  ____        _   _             _  _   
# |  _ \      | | | |           | || |  
# | |_) |_   _| |_| |_ ___  _ __| || |_ 
# |  _ <| | | | __| __/ _ \| '_ \__   _|
# | |_) | |_| | |_| || (_) | | | | | |  
# |____/ \__,_|\__|\__\___/|_| |_| |_|  
                                                                              
def button4_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["/usr/bin/python3", "/CHOOSE/CORRECT/PATH/butternode_sdk_v6/Linux/Network/UDPclient.py"])


button4=tkinter.Button(my_w, 
                       text="UDPclient", 
                       activeforeground="red",
                       command=button4_callback,
                       fg="black",
                       state="disabled"
                       )
button4.grid(row=5,column=0)

#  ____        _   _              _____ 
# |  _ \      | | | |            | ____|
# | |_) |_   _| |_| |_ ___  _ __ | |__  
# |  _ <| | | | __| __/ _ \| '_ \|___ \ 
# | |_) | |_| | |_| || (_) | | | |___) |
# |____/ \__,_|\__|\__\___/|_| |_|____/                                        
                                       
def button5_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["/usr/bin/python3", "/CHOOSE/CORRECT/PATH/butternode_sdk_v6/Linux/Network/UDPserver.py"])


button5=tkinter.Button(my_w, 
                       text="UDPserver", 
                       activeforeground="red",
                       command=button5_callback,
                       fg="black",
                       state="disabled"
                       )
button5.grid(row=6,column=0)

#  ____        _   _                __  
# |  _ \      | | | |              / /  
# | |_) |_   _| |_| |_ ___  _ __  / /_  
# |  _ <| | | | __| __/ _ \| '_ \| '_ \ 
# | |_) | |_| | |_| || (_) | | | | (_) |
# |____/ \__,_|\__|\__\___/|_| |_|\___/                                        
                                       
def button6_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["/usr/bin/python3", "/CHOOSE/CORRECT/PATH/butternode_sdk_v6/Linux/Scripts/networksfinder.py"])


button6=tkinter.Button(my_w, 
                       text="button6", 
                       activeforeground="red",
                       command=button6_callback,
                       fg="black",
                       state="active"
                       )
button6.grid(row=7,column=0)

#  ____        _   _             ______ 
# |  _ \      | | | |           |____  |
# | |_) |_   _| |_| |_ ___  _ __    / / 
# |  _ <| | | | __| __/ _ \| '_ \  / /  
# | |_) | |_| | |_| || (_) | | | |/ /   
# |____/ \__,_|\__|\__\___/|_| |_/_/                                          
                                       
def button7_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["whoami"])


button7=tkinter.Button(my_w, 
                       text="button7", 
                       activeforeground="red",
                       command=button7_callback,
                       fg="black",
                       state="disabled"
                       )
button7.grid(row=8,column=0)

#  ____        _   _               ___  
# |  _ \      | | | |             / _ \ 
# | |_) |_   _| |_| |_ ___  _ __ | (_) |
# |  _ <| | | | __| __/ _ \| '_ \ > _ < 
# | |_) | |_| | |_| || (_) | | | | (_) |
# |____/ \__,_|\__|\__\___/|_| |_|\___/                                                                               

def button8_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["whoami"])


button8=tkinter.Button(my_w, 
                       text="button8", 
                       activeforeground="red",
                       command=button8_callback,
                       fg="black",
                       state="disabled"
                       )
button8.grid(row=1,column=1)

#  ____        _   _             ___  
# |  _ \      | | | |           / _ \ 
# | |_) |_   _| |_| |_ ___  _ _| (_) |
# |  _ <| | | | __| __/ _ \| '_ \__, |
# | |_) | |_| | |_| || (_) | | | |/ / 
# |____/ \__,_|\__|\__\___/|_| |_/_/                                     
                                     
def button9_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["whoami"])


button9=tkinter.Button(my_w, 
                       text="button9", 
                       activeforeground="red",
                       command=button9_callback,
                       fg="black",
                       state="disabled"
                       )
button9.grid(row=2,column=1)

#  ____        _   _             __  ___  
# |  _ \      | | | |           /_ |/ _ \ 
# | |_) |_   _| |_| |_ ___  _ __ | | | | |
# |  _ <| | | | __| __/ _ \| '_ \| | | | |
# | |_) | |_| | |_| || (_) | | | | | |_| |
# |____/ \__,_|\__|\__\___/|_| |_|_|\___/ 
                                                                                  
def button10_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["whoami"])


button10=tkinter.Button(my_w, 
                        text="button10", 
                        activeforeground="red",
                        command=button10_callback,
                        fg="black",
                        state="disabled"
                        )
button10.grid(row=3,column=1)

#  ____        _   _             __ __ 
# |  _ \      | | | |           /_ /_ |
# | |_) |_   _| |_| |_ ___  _ __ | || |
# |  _ <| | | | __| __/ _ \| '_ \| || |
# | |_) | |_| | |_| || (_) | | | | || |
# |____/ \__,_|\__|\__\___/|_| |_|_||_|                                      
                                      
def button11_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["whoami"])


button11=tkinter.Button(my_w, 
                        text="button11", 
                        activeforeground="red",
                        command=button11_callback,
                        fg="black",
                        state="disabled"
                        )
button11.grid(row=5,column=1)

#  ____        _   _             __ ___  
# |  _ \      | | | |           /_ |__ \ 
# | |_) |_   _| |_| |_ ___  _ __ | |  ) |
# |  _ <| | | | __| __/ _ \| '_ \| | / / 
# | |_) | |_| | |_| || (_) | | | | |/ /_ 
# |____/ \__,_|\__|\__\___/|_| |_|_|____|                                        
                                        
def button12_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["whoami"])


button12=tkinter.Button(my_w, 
                        text="button12",
                        activeforeground="red",
                        command=button12_callback,
                        fg="black",
                        state="disabled"
                        )
button12.grid(row=6,column=1)

#  ____        _   _             __ ____  
# |  _ \      | | | |           /_ |___ \ 
# | |_) |_   _| |_| |_ ___  _ __ | | __) |
# |  _ <| | | | __| __/ _ \| '_ \| ||__ < 
# | |_) | |_| | |_| || (_) | | | | |___) |
# |____/ \__,_|\__|\__\___/|_| |_|_|____/                                          
                                         
def button13_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["whoami"])


button13=tkinter.Button(my_w, 
                        text="button13", 
                        activeforeground="red",
                        command=button13_callback,
                        fg="black",
                        state="disabled"
                        )
button13.grid(row=7,column=1)

#  ____        _   _             __ _  _   
# |  _ \      | | | |           /_ | || |  
# | |_) |_   _| |_| |_ ___  _ __ | | || |_ 
# |  _ <| | | | __| __/ _ \| '_ \| |__   _|
# | |_) | |_| | |_| || (_) | | | | |  | |  
# |____/ \__,_|\__|\__\___/|_| |_|_|  |_|                                            
                                          
def button14_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["whoami"])


button14=tkinter.Button(my_w, 
                        text="button14", 
                        activeforeground="red",
                        command=button14_callback,
                        fg="black",
                        state="disabled"
                        )
button14.grid(row=8,column=1)

#  ____        _   _             __ _____ 
# |  _ \      | | | |           /_ | ____|
# | |_) |_   _| |_| |_ ___  _ __ | | |__  
# |  _ <| | | | __| __/ _ \| '_ \| |___ \ 
# | |_) | |_| | |_| || (_) | | | | |___) |
# |____/ \__,_|\__|\__\___/|_| |_|_|____/                                                                                   

def button15_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["whoami"])


button15=tkinter.Button(my_w, 
                        text="button15", 
                        activeforeground="red",
                        command=button15_callback,
                        fg="black",
                        state="disabled"
                        )
button15.grid(row=1,column=2)

#  ____        _   _             __   __  
# |  _ \      | | | |           /_ | / /  
# | |_) |_   _| |_| |_ ___  _ __ | |/ /_  
# |  _ <| | | | __| __/ _ \| '_ \| | '_ \ 
# | |_) | |_| | |_| || (_) | | | | | (_) |
# |____/ \__,_|\__|\__\___/|_| |_|_|\___/                                          
                                         
def button16_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["whoami"])


button16=tkinter.Button(my_w, 
                        text="button16", 
                        activeforeground="red",
                        command=button16_callback,
                        fg="black",
                        state="disabled"
                        )
button16.grid(row=2,column=2)

#  ____        _   _             __ ______ 
# |  _ \      | | | |           /_ |____  |
# | |_) |_   _| |_| |_ ___  _ __ | |   / / 
# |  _ <| | | | __| __/ _ \| '_ \| |  / /  
# | |_) | |_| | |_| || (_) | | | | | / /   
# |____/ \__,_|\__|\__\___/|_| |_|_|/_/                                              
                                          
def button17_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["whoami"])


button17=tkinter.Button(my_w, 
                        text="button17", 
                        activeforeground="red",
                        command=button17_callback,
                        fg="black",
                        state="disabled"
                        )
button17.grid(row=3,column=2)

#  ____        _   _             __  ___  
# |  _ \      | | | |           /_ |/ _ \ 
# | |_) |_   _| |_| |_ ___  _ __ | | (_) |
# |  _ <| | | | __| __/ _ \| '_ \| |> _ < 
# | |_) | |_| | |_| || (_) | | | | | (_) |
# |____/ \__,_|\__|\__\___/|_| |_|_|\___/                                          
                                         
def button18_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["whoami"])


button18=tkinter.Button(my_w, 
                        text="button18", 
                        activeforeground="red",
                        command=button18_callback,
                        fg="black",
                        state="disabled"
                        )
button18.grid(row=5,column=2)

#  ____        _   _             __  ___  
# |  _ \      | | | |           /_ |/ _ \ 
# | |_) |_   _| |_| |_ ___  _ __ | | (_) |
# |  _ <| | | | __| __/ _ \| '_ \| |\__, |
# | |_) | |_| | |_| || (_) | | | | |  / / 
# |____/ \__,_|\__|\__\___/|_| |_|_| /_/                                           
                                         
def button19_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["whoami"])


button19=tkinter.Button(my_w, 
                        text="button19", 
                        activeforeground="red",
                        command=button19_callback,
                        fg="black",
                        state="disabled"
                        )
button19.grid(row=6,column=2)

#  ____        _   _              ___   ___  
# |  _ \      | | | |            |__ \ / _ \ 
# | |_) |_   _| |_| |_ ___  _ __    ) | | | |
# |  _ <| | | | __| __/ _ \| '_ \  / /| | | |
# | |_) | |_| | |_| || (_) | | | |/ /_| |_| |
# |____/ \__,_|\__|\__\___/|_| |_|____|\___/                                             
                                            
def button20_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["whoami"])


button20=tkinter.Button(my_w, 
                        text="button20", 
                        activeforeground="red",
                        command=button20_callback,
                        fg="black",
                        state="disabled"
                        )
button20.grid(row=7,column=2)

#  ____        _   _              ___  __ 
# |  _ \      | | | |            |__ \/_ |
# | |_) |_   _| |_| |_ ___  _ __    ) || |
# |  _ <| | | | __| __/ _ \| '_ \  / / | |
# | |_) | |_| | |_| || (_) | | | |/ /_ | |
# |____/ \__,_|\__|\__\___/|_| |_|____||_|                                         
                                         
def button21_callback():
    ### <!--- *** REFRESHINGLY *** --->
    subprocess.run(["clear"])


button21=tkinter.Button(my_w, 
                        text="button21", 
                        activeforeground="red",
                        command=button21_callback,
                        fg="black",
                        state="active"
                        )
button21.grid(row=8,column=2)



button22=tkinter.Button(my_w, text="Exit", activeforeground="red", command=my_w.destroy)
button22.grid(row=9,column=1)



my_w.mainloop()




