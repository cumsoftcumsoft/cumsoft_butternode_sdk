*Cumsoft_Butternode_V6_<3*


         ⚠️⚠️ CODE NOT WORKING?? ⚠️⚠️

///////////////////////////////////////////////
//    Because of Rolling Distrobution        //
//  CUMSOFTBUTTERNODESDK File Path Locations //
//     Are Subject to CHANGE, THUS PLZ       //
//   SCRAPE & QUIERY THE ENTIRE PACKAGE      //
//            4 SYNTAX BELOW MENTIONED BELOW //
//      *** SYNTAX: "REFRESHINGLY" ***       //
///////////////////////////////////////////////

### *About*
* *Cumsoft_Butternode_SDK* (Working Title) is a CLT made for the purpose of remote tool access. User case would be like walking into your local library or perhaps best buy; where a terminal is present for the public. Is this terminal connected to other devices? Using the *Cumsoft_Butternode_SDK* you can find out. It is not limited to wild terminals but can be used for athome systems aswell.

* *Cumsoft_Butternode_SDK* is Foss, *Cumsoft_Butternode_SDK* is a volatile project meaning; its a rolling project and is subject to changes/updates/deletion. *Cumsoft_Butternode_SDK* Project page is found here on Github; thus is subject to deletion. It is strongly recommened that each iteration of development be archived. 

### *RULES* 
* Best practice is to Download the most recent package found Here: hxxps://github.com/cumsoftcumsoft/cumsoft_butternode_sdk. Once edits are made please push the project to a sub branch of "main" called "switch" *DO NOT PUSH UPDATED PACKAGES TO MAIN*
* Also when pushing your alterations back to the "switch" branch please us naming convetions that align. Examples: butternode_sdk_v4.zip or smaller changes can be named butternode_sdk_v4.1.1-butternode_sdk_v4.100.100.zip.
* If you have any issues please open a discussion thread and write a detailed outline of the issue/bug. Thank you!
* When making alterations to *Cumsoft_Butternode_SDK* Please document all changes to the original package in the README.txt.
* *HAVE FUN* 

### *UPDATES BULLETIN*
* [butternode_sdk_v1.zip] (5/5/23 | 130kb)<!--- // Entry of "Cumsoft_Butternode_SDK"; Webserver for Mass-deployment // --->
* [butternode_sdk_v2.zip] (5/8/23 | 133kb)<!--- // Java Lang Integration; Windows WebApp Util Expansion // --->
* [butternode_sdk_v3Beta.zip] (6/16/23 | 2.37 MB)<!--- // Multiwindow Main Menu, README.md Updated, Expansion 4 Windows Apps // --->
* [butternode_sdk_v4.zip] (6/16/23 | 2.39 MB)<!--- // Multiwindow Main Menu, README.md Updated, Expansion 4 Linux Bash MEnu & Python3 Menu // --->
* [butternode_sdk_v5.zip] (6/17/23 | 2.39 MB)<!--- // BreakThrough Bash Terminal Menu w Python Gui Expansion and code exacution. Mark version 5 as Keystone Progress // --->

* [butternode_sdk_v6.zip] (6/25/23 | ??? MB)<!--- // MOST STABLE RELEASE // --->


### *PACKAGE TREE*

<br> 📁 Cumsoft_Butternode_SDK_v6
<br>│├─ 📁 Cumsoft_Butternode_SDK_v6
<br>│ | ├─ 📁 Cumsoft_Butternode_SDK_v6
<br>
<br>
<br>
<br>├─ 📁 Java
<br>│├─ 📁 Genenv
<br>│├─ 📁 Main_App
<br>│ | ├─ 📁 Resources
<br>|
<br>├─ 📁 Linux
<br>│├─ 📁 Main_App
<br>│|  ├─ app_404.html
<br>│|  ├─ app_invokephp.html
<br>│|  ├─ app_invokepy.html
<br>│|  ├─ Linux_app.html
<br>│|  ├─ 📁 Resources
<br>│|  |  ├─ app_404.html
<br>│|  |  ├─ robots.txt
<br>│├─ 📁 Network
<br>│|  ├─ TCPclient.py
<br>│|  ├─ TCPserver.py
<br>│|  ├─ UDPclient.py
<br>│|  ├─ UDPserver.py
<br>│├─ 📁 Scripts
<br>│|  ├─ crawlerdir.py
<br>│|  ├─ cumsoftbutternodesdkmenu.py
<br>│|  ├─ cumsoftbutternodesdkmenu.sh
<br>│|  ├─ firstbootinstaller.sh
<br>│|  ├─ nimfrompython.py
<br>│|  ├─ placeholder.py
<br>|
<br>|
<br>├─ README.md
<br>├─ requirements.txt
<br>├─ robots.txt
<br>|
<br>├─ 📁 Windows
<br>│ | ├─ adminbypass.bat
<br>│ | ├─ firstbootinstaller.ps1
<br>│├─ 📁 Genenv
<br>│ | ├─ logger.txt.txt
<br>│├─ 📁 Main_App
<br>│ | ├─ app_404.html
<br>│ | ├─ app_invokecsharp.html
<br>│ | ├─ app_invokevbs.html
<br>│ | ├─ 📁 Resources
<br>│ | |  ├─ cumsoftbutton_yellow.png
<br>│ | |  ├─ getoperatingsysteminfo.hta
<br>│ | |  ├─ getproductkey.vbs
<br>│ | |  ├─ htmlcreatehtml.html
<br>│ | |  ├─ Launchsyntax.hta
<br>│ | |  ├─ Launchsyntaxother.hta
<br>│ | |  ├─ Powershellsecrets.ps1
<br>│ | |  ├─ Winregistrybypass.reg.txt
<br>│ | |  ├─ wooper.hta
<br>│ | ├─ Windows_app.html
<br>│ | ├─ 📁 Network
<br>│ | ├─ 📁 Scripts
<br>│ | ├─ notes.ps1
<br>|
<br>|
<br>├─ 📁 WIP
<br>│   ├─ EnviromentalVariables.txt
<br>|
<br>|
<br>├─ */Github Standard Packages/*
<br>├─ .gitignore
<br>├─ package.json
<br>├─ node_modules/

