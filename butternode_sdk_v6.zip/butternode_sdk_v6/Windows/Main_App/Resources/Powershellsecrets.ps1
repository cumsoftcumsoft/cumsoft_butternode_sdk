




<#
--------------------------------------
LastUseTime, LocalPath, and SID.
--------------------------------------
#>
PS C:\Windows\system32> gwmi win32_userprofile



<#
--------------------------------------
LastUseTime, LocalPath, and SID.
--------------------------------------
#>
PS C:\Windows\system32> gwmi win32_userprofile | select lastusetime, localpath, sid

<#
--------------------------------------
No IDea
--------------------------------------
#>
PS C:\Windows\system32> get-childitem| % {write-host $_.length $_.name -separator "`t`t"}

ALso This

PS C:\Windows\system32> Get-ChildItem | Select-Object basename | Sort-Object *


<#
--------------------------------------
Sleep Func
--------------------------------------
#>
PS C:\Windows\system32> Start-Sleep


<#
--------------------------------------
Creates a new file, directory, symbolic link, registry key, or registry entry
--------------------------------------
#>

PS C:\Users\timothy> New-Item -Path .\ -Name "testfile1.txt" -ItemType "file" -Value "This is a text string."

<#
--------------------------------------
Get Product KEy
--------------------------------------
#>
PS C:\Users\timothy> Get-WmiObject -query ‘select * from SoftwareLicensingService’).OA3xOriginalProductKey



<#
--------------------------------------
Product Key info?
--------------------------------------
#>
PS C:\Users\timothy> Get-CimInstance -query 'select * from SoftwareLicensingService'


<#
--------------------------------------
Product Key info?
--------------------------------------
#>

PS C:\Users\timothy> Get-psdrive