 <#
hxxps://github.com/cumsoftcumsoft/cumsoft_butternode_sdk
#>
,____________________________________________________,
|____________________________________________________|

<#
    .Set-ExecutionPolicy
    The Set-ExecutionPolicy function allows unsigned scripts to run without signing
#>

PS C: \> $Set-ExecutionPolicy -ExecutionPolicy RemoteSigned
PS C: \> $ "C:C:\CHOOSE\CORRECT\PATH\butternode_sdk_v6\\\\firstbootinstaller.ps1"

,____________________________________________________,
|____________________________________________________|


<#
    .Get-LocalUser
    The Get-LocalUser function displays user info
#>

PS C: \> $ Get-LocalUser | Select *
