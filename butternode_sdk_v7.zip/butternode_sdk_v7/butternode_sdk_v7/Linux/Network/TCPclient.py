import socket
from datetime import datetime

server_address = ('localhost', 6789)
max_size = 1000

print('Starting the client at', datetime.now())
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(address)
client.sendall(b'Hey!')
data = client.recv(max_size)
print('At', datetime.now(), 'Someone Replied', data)
client.close()


## NEWER-BACKUP ##

#import socket
#import sys
#
#HOST, PORT = "localhost", 9999
#data = " ".join(sys.argv[1:])
#
## Create a socket (SOCK_STREAM means a TCP socket)
#with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
#    # Connect to server and send data
#    sock.connect((HOST, PORT))
#    sock.sendall(bytes(data + "\n", "utf-8"))
#
#    # Receive data from the server and shut down
#    received = str(sock.recv(1024), "utf-8")
#
#print("Sent:     {}".format(data))
#print("Received: {}".format(received))