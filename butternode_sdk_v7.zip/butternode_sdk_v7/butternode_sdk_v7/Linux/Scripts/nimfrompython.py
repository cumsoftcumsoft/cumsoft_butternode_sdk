import subprocess

def launch_nim_script():
    nim_script_path = "path/to/my_script.nim"
    nim_command = ["nim", "c", "-r", nim_script_path]
    subprocess.call(nim_command)

# Call the function to launch the Nim script
launch_nim_script()
