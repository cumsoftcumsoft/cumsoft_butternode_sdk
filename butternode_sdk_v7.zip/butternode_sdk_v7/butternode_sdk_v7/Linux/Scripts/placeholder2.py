
#
# This is a countdown timer :)
#

import time
print("!!!!!!!!!!!!!")
print("!!!!!!!!!!!!!")
print("!!! TIMER !!!")
print("!!!!!!!!!!!!!")
print("!!!!!!!!!!!!!")
time.sleep(1)
custom_time = input("Enter amount of seconds: ")
new_custom_time = int(custom_time) 
print("5")
time.sleep(1)
print("4")
time.sleep(1)
print("3")
time.sleep(1)
print("2")
time.sleep(1)
print("1")
time.sleep(1)
print("")
print("The countdown will start now!")
print("")
while new_custom_time != 0:
  print(new_custom_time)
  new_custom_time = new_custom_time -1
  time.sleep(1)
print("")
print("!!!!!!!!!!!!!")
print("!!!!!!!!!!!!!")
print("!! TIME UP !!")
print("!!!!!!!!!!!!!")
print("!!!!!!!!!!!!!")