#
#
#
#
#
#
#
#
#
#
#


# Pipeline
# Get-Process
# Get-Service
# Get-Member

# Providers
# Get-PSProvider

# Sessions
# New-PSSession
# Enter-PSSession


# Searching Commands
# Get-Command -Noun *Network*
# Get-Command -version
# Get-Command -verb Get

# Stop Processes
# Get- PRocess Win32calc | Stop-Process

# Modules
# Get-Module -ListAvailable
# Get-Module
# Get-Member

# Export Data from PS1
# Get-Process | Out-File -filepath C:\PSTEMP\Process.txt

# Export CVS
# Get-Process | Export-Csv -Path C:\PSTEMP\Processes.csv

# Import CVS
# Procs = Import-Csv -Path c:\PSTEMP\Processes.csv

# Exporting HTML/XML
# Get-Process | ConvertTo-Html | Out-File c:\PSTEMP\processes.html

# Sorting through Objects
# Get-Process | Sort-Object -Property CPU
# Get-Process | Sort-Object -Property CPU | Select-Object -Last 5
# Get-Process | Format-List
# Get-Process | Format-Table -AutoSize
# Get-Process | Format-Wide

# Remote Control
# Invoke Command
# Invoke-Command -ComputerName Server3 -Credential domain\username -ScriptBlock (Get-Process)
# New-PSSession
# New-PSSession -ComputerName Server3

# Get Help
# Get-Help
# Get-Help Get-Process
# Get-Help process
# Get-Help Get-Process -Full

# Sign your scripts
# Set-AuthenticodeSignature c:\doWhile.ps1 @(Get-ChildItem cert:\ CurrentUser\My -codesign)[0]


# Export Windows Passwords
# reg save HKLM\sam ./sam.save
# reg save HKLM\system ./system.save

# Open Finder Folder
# explorer .
















